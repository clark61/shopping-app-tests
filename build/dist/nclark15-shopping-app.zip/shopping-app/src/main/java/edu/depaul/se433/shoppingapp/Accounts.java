/*
 * SE 333 Class project
 * Author: Dan Walker
 * Copyright 2020
 */
package edu.depaul.se433.shoppingapp;

/**
 * The Accounts class is responsible for making sure user accounts are kept up to date.
 */
public class Accounts {

  public static void recordPurchase(double cost, String name, String state) {

  }
}
